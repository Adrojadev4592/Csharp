﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rektangular_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[, ,] a = new int[3, 3, 3];
            a[0, 0, 0] = 1;
            a[0, 0, 1] = 2;
            a[0, 0, 2] = 3;
            a[0, 1, 0] = 4;
            a[0, 1, 1] = 5;
            a[0, 1, 2] = 6;
            foreach (int i in a)
            {
                Console.Write(i);
            }
            Console.Read();
        }
    }
}
