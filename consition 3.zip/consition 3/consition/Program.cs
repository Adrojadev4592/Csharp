﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace consition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());
            if (age > 0)
            {
                if (age >= 10 && age < 60)
                {
                    Console.WriteLine("Adult");
                } else if (age < 18)
                {
               
                    Console.WriteLine("teenage");
                }
                else if (age > 60)
                {
                    Console.WriteLine("seanior citzion");
                }

            }
            else {
                Console.Write("coming soon");
            }
            Console.Read();
        }
    }
}
